-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 08 May 2026, 17:48:25
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `vtys_proje`
--

DELIMITER $$
--
-- Yordamlar
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_MaasGuncelle` (IN `p_PersonelID` INT, IN `p_YeniUcret` DECIMAL(10,2))   BEGIN
    UPDATE Personeller SET SaatlikUcret = p_YeniUcret WHERE PersonelID = p_PersonelID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `departmanlar`
--

CREATE TABLE `departmanlar` (
  `DepartmanID` int(11) NOT NULL,
  `DepartmanAdi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `departmanlar`
--

INSERT INTO `departmanlar` (`DepartmanID`, `DepartmanAdi`) VALUES
(1, 'Yazılım'),
(2, 'İnsan Kaynakları'),
(3, 'Muhasebe'),
(4, 'Pazarlama'),
(6, 'Satış'),
(7, 'Lojistik');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `devam_takip`
--

CREATE TABLE `devam_takip` (
  `TakipID` int(11) NOT NULL,
  `PersonelID` int(11) DEFAULT NULL,
  `Tarih` date NOT NULL,
  `GirisSaati` time DEFAULT NULL,
  `CikisSaati` time DEFAULT NULL,
  `ToplamMesaiSaat` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `devam_takip`
--

INSERT INTO `devam_takip` (`TakipID`, `PersonelID`, `Tarih`, `GirisSaati`, `CikisSaati`, `ToplamMesaiSaat`) VALUES
(1, 1, '2023-10-01', '08:00:00', '17:00:00', 9.00),
(2, 2, '2023-10-01', '08:30:00', '18:30:00', 10.00);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE `kullanicilar` (
  `id` int(11) NOT NULL,
  `kullanici_adi` varchar(50) NOT NULL,
  `sifre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`id`, `kullanici_adi`, `sifre`) VALUES
(1, 'admin', '1234');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `maas_odemeleri`
--

CREATE TABLE `maas_odemeleri` (
  `OdemeID` int(11) NOT NULL,
  `PersonelID` int(11) DEFAULT NULL,
  `ToplamMaas` decimal(10,2) NOT NULL,
  `OdemeTarihi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `maas_odemeleri`
--

INSERT INTO `maas_odemeleri` (`OdemeID`, `PersonelID`, `ToplamMaas`, `OdemeTarihi`) VALUES
(1, 1, 25000.00, '2023-10-31'),
(2, 2, 30000.00, '2023-10-31');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `personeller`
--

CREATE TABLE `personeller` (
  `PersonelID` int(11) NOT NULL,
  `Ad` varchar(50) NOT NULL,
  `Soyad` varchar(50) NOT NULL,
  `SaatlikUcret` decimal(10,2) NOT NULL,
  `DepartmanID` int(11) DEFAULT NULL,
  `GirisSaati` time DEFAULT '09:00:00',
  `CikisSaati` time DEFAULT '18:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Tablo döküm verisi `personeller`
--

INSERT INTO `personeller` (`PersonelID`, `Ad`, `Soyad`, `SaatlikUcret`, `DepartmanID`, `GirisSaati`, `CikisSaati`) VALUES
(1, 'Enes', 'Demir', 250.00, 1, '09:00:00', '18:00:00'),
(2, 'Anıl', 'Duyar', 300.00, 1, '09:00:00', '18:00:00'),
(3, 'Ömer', 'Öney', 300.00, 2, '09:00:00', '18:00:00'),
(4, 'Yusuf', 'Yalçın', 200.00, 3, '09:00:00', '18:00:00'),
(6, 'Miraç ', 'Yardımcı', 300.00, 6, '11:00:00', '20:00:00'),
(7, 'Ahmet', 'Kara', 275.00, 2, '08:00:00', '17:00:00');

--
-- Tetikleyiciler `personeller`
--
DELIMITER $$
CREATE TRIGGER `trg_PersonelSilindi` AFTER DELETE ON `personeller` FOR EACH ROW BEGIN
    INSERT INTO Personel_Log (PersonelAdSoyad) VALUES (CONCAT(OLD.Ad, ' ', OLD.Soyad));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `personel_log`
--

CREATE TABLE `personel_log` (
  `LogID` int(11) NOT NULL,
  `PersonelAdSoyad` varchar(255) DEFAULT NULL,
  `IslemTarihi` datetime DEFAULT current_timestamp(),
  `IslemTipi` varchar(50) DEFAULT 'SILINDI'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Görünüm yapısı durumu `vw_personel_departman`
-- (Asıl görünüm için aşağıya bakın)
--
CREATE TABLE `vw_personel_departman` (
`Ad` varchar(50)
,`Soyad` varchar(50)
,`DepartmanAdi` varchar(100)
);

-- --------------------------------------------------------

--
-- Görünüm yapısı `vw_personel_departman`
--
DROP TABLE IF EXISTS `vw_personel_departman`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_personel_departman`  AS SELECT `p`.`Ad` AS `Ad`, `p`.`Soyad` AS `Soyad`, `d`.`DepartmanAdi` AS `DepartmanAdi` FROM (`personeller` `p` join `departmanlar` `d` on(`p`.`DepartmanID` = `d`.`DepartmanID`)) ;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `departmanlar`
--
ALTER TABLE `departmanlar`
  ADD PRIMARY KEY (`DepartmanID`);

--
-- Tablo için indeksler `devam_takip`
--
ALTER TABLE `devam_takip`
  ADD PRIMARY KEY (`TakipID`),
  ADD KEY `PersonelID` (`PersonelID`);

--
-- Tablo için indeksler `kullanicilar`
--
ALTER TABLE `kullanicilar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `maas_odemeleri`
--
ALTER TABLE `maas_odemeleri`
  ADD PRIMARY KEY (`OdemeID`),
  ADD KEY `PersonelID` (`PersonelID`);

--
-- Tablo için indeksler `personeller`
--
ALTER TABLE `personeller`
  ADD PRIMARY KEY (`PersonelID`),
  ADD KEY `DepartmanID` (`DepartmanID`);

--
-- Tablo için indeksler `personel_log`
--
ALTER TABLE `personel_log`
  ADD PRIMARY KEY (`LogID`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `departmanlar`
--
ALTER TABLE `departmanlar`
  MODIFY `DepartmanID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `devam_takip`
--
ALTER TABLE `devam_takip`
  MODIFY `TakipID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `kullanicilar`
--
ALTER TABLE `kullanicilar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `maas_odemeleri`
--
ALTER TABLE `maas_odemeleri`
  MODIFY `OdemeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `personeller`
--
ALTER TABLE `personeller`
  MODIFY `PersonelID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `personel_log`
--
ALTER TABLE `personel_log`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `devam_takip`
--
ALTER TABLE `devam_takip`
  ADD CONSTRAINT `devam_takip_ibfk_1` FOREIGN KEY (`PersonelID`) REFERENCES `personeller` (`PersonelID`);

--
-- Tablo kısıtlamaları `maas_odemeleri`
--
ALTER TABLE `maas_odemeleri`
  ADD CONSTRAINT `maas_odemeleri_ibfk_1` FOREIGN KEY (`PersonelID`) REFERENCES `personeller` (`PersonelID`);

--
-- Tablo kısıtlamaları `personeller`
--
ALTER TABLE `personeller`
  ADD CONSTRAINT `personeller_ibfk_1` FOREIGN KEY (`DepartmanID`) REFERENCES `departmanlar` (`DepartmanID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
