<?php
session_start();
if(!isset($_SESSION['admin'])){ header("Location: login.php"); exit(); }

$host = 'localhost'; $dbname = 'vtys_proje'; $user = 'root'; $pass = '';
try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
} catch (PDOException $e) { die("Bağlantı hatası"); }

if(isset($_GET['logout'])){ session_destroy(); header("Location: login.php"); exit(); }

if(isset($_GET['sil'])){
    $db->prepare("DELETE FROM Personeller WHERE PersonelID = ?")->execute([$_GET['sil']]);
    header("Location: index.php"); exit();
}

if (isset($_POST['kaydet'])) {
    $sorgu = $db->prepare("INSERT INTO Personeller (Ad, Soyad, SaatlikUcret, DepartmanID, GirisSaati, CikisSaati) VALUES (?, ?, ?, ?, ?, ?)");
    $sorgu->execute([$_POST['ad'], $_POST['soyad'], $_POST['ucret'], $_POST['dept_id'], $_POST['giris'], $_POST['cikis']]);
    header("Location: index.php?durum=ok"); exit();
}

// Grafik Verisi
$grafik = $db->query("SELECT d.DepartmanAdi, COUNT(p.PersonelID) as sayi FROM Departmanlar d LEFT JOIN Personeller p ON d.DepartmanID = p.DepartmanID GROUP BY d.DepartmanID")->fetchAll(PDO::FETCH_ASSOC);
$labels = []; $counts = [];
foreach($grafik as $g){ $labels[] = $g['DepartmanAdi']; $counts[] = $g['sayi']; }
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Personel Takip Sistemi | Yönetim Paneli</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #f8fafc; font-family: 'Segoe UI', sans-serif; }
        .navbar { background: #1e293b; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .btn-add { background: #6366f1; color: white; border: none; }
        .badge-money { background: #dcfce7; color: #166534; font-weight: bold; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark py-3 mb-4">
    <div class="container d-flex justify-content-between">
        <span class="navbar-brand fw-bold"><i class="fas fa-users-gear me-2"></i> Personel Takip Sistemi </span>
        <a href="?logout=1" class="btn btn-outline-danger btn-sm px-4 rounded-pill">Güvenli Çıkış</a>
    </div>
</nav>

<div class="container">
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card p-4 h-100">
                <h5 class="fw-bold mb-4 text-primary"><i class="fas fa-user-plus me-2"></i>Yeni Kayıt</h5>
                <form method="POST">
                    <input type="text" name="ad" class="form-control mb-3" placeholder="Ad" required>
                    <input type="text" name="soyad" class="form-control mb-3" placeholder="Soyad" required>
                    <select name="dept_id" class="form-select mb-3">
                        <?php foreach($db->query("SELECT * FROM Departmanlar") as $d): ?>
                            <option value="<?=$d['DepartmanID']?>"><?=$d['DepartmanAdi']?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="input-group mb-3">
                        <span class="input-group-text">₺</span>
                        <input type="number" name="ucret" class="form-control" placeholder="Saatlik Ücret" required>
                    </div>
                    <div class="row mb-4 text-secondary small">
                        <div class="col"><label>Giriş</label><input type="time" name="giris" class="form-control" value="09:00"></div>
                        <div class="col"><label>Çıkış</label><input type="time" name="cikis" class="form-control" value="18:00"></div>
                    </div>
                    <button type="submit" name="kaydet" class="btn btn-add w-100 fw-bold py-2 shadow-sm">Personeli Kaydet</button>
                </form>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card p-4 h-100">
                <h5 class="fw-bold mb-4 text-primary"><i class="fas fa-list-check me-2"></i>Aktif Çalışanlar</h5>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light small">
                            <tr>
                                <th>Ad Soyad</th>
                                <th>Departman</th>
                                <th>Maaş Hesabı</th>
                                <th class="text-end">Aksiyon</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $personeller = $db->query("SELECT p.*, d.DepartmanAdi FROM Personeller p LEFT JOIN Departmanlar d ON p.DepartmanID = d.DepartmanID ORDER BY p.PersonelID DESC");
                            while($row = $personeller->fetch(PDO::FETCH_ASSOC)): 
                                $saat_farki = (strtotime($row['CikisSaati']) - strtotime($row['GirisSaati'])) / 3600;
                                $gunluk = $saat_farki * $row['SaatlikUcret'];
                            ?>
                            <tr>
                                <td><strong><?=$row['Ad']." ".$row['Soyad']?></strong><br><small class="text-muted">ID: #<?=$row['PersonelID']?></small></td>
                                <td><span class="badge bg-light text-dark"><?=$row['DepartmanAdi'] ?? 'Genel'?></span></td>
                                <td>
                                    <small class="d-block text-muted"><?=substr($row['GirisSaati'],0,5)?>-<?=substr($row['CikisSaati'],0,5)?></small>
                                    <span class="badge badge-money"><?=number_format($gunluk, 2)?> ₺ / Gün</span>
                                </td>
                                <td class="text-end">
                                    <a href="?sil=<?=$row['PersonelID']?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Siliniyor, onaylıyor musun?')"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <hr class="my-5">
    <div class="row g-4 mb-5">
        <div class="col-md-7">
            <div class="card p-4">
                <h5 class="fw-bold mb-4 text-secondary"><i class="fas fa-chart-pie me-2"></i>Departman Analizi</h5>
                <canvas id="myChart" style="max-height: 280px;"></canvas>
            </div>
        </div>
        <div class="col-md-5">
            <div class="row g-3">
                <div class="col-12">
                    <div class="card p-4 bg-primary text-white">
                        <small class="opacity-75">Toplam Personel</small>
                        <h2 class="fw-bold m-0"><?=$db->query("SELECT count(*) FROM Personeller")->fetchColumn()?> Kişi</h2>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card p-4 bg-success text-white">
                        <small class="opacity-75">Sistemdeki Toplam Saatlik Gider</small>
                        <h2 class="fw-bold m-0"><?=number_format($db->query("SELECT SUM(SaatlikUcret) FROM Personeller")->fetchColumn(), 2)?> ₺</h2>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card p-4 bg-white border">
                        <small class="text-muted">Aktif Departman Sayısı</small>
                        <h2 class="fw-bold m-0 text-dark"><?=$db->query("SELECT count(*) FROM Departmanlar")->fetchColumn()?></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const ctx = document.getElementById('myChart');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?=json_encode($labels)?>,
            datasets: [{
                label: 'Personel Sayısı',
                data: <?=json_encode($counts)?>,
                backgroundColor: '#6366f1',
                borderRadius: 10
            }]
        },
        options: { indexAxis: 'y', plugins: { legend: { display: false } } }
    });
</script>
</body>
</html>