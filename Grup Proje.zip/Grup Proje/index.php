<?php
// Olası hataları gizlemesin, bize göstersin diye eklediğimiz kod:
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 1. VERİTABANI BAĞLANTISI (PDO KULLANARAK)
$host = 'localhost';
$dbname = 'vtys_proje'; // Biraz önce kurduğumuz veritabanı
$user = 'root';         // XAMPP varsayılan kullanıcı adı
$pass = '';             // XAMPP varsayılan şifresi

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
} catch (PDOException $e) {
    die("Bağlantı hatası: " . $e->getMessage());
}

// 2. PERSONEL EKLEME (Eğer formdan "Kaydet" butonuna basılırsa çalışır)
if (isset($_POST['kaydet'])) {
    $ad = $_POST['ad'];
    $soyad = $_POST['soyad'];
    $ucret = $_POST['ucret'];

    $sorgu = $db->prepare("INSERT INTO Personeller (Ad, Soyad, SaatlikUcret) VALUES (?, ?, ?)");
    $sorgu->execute([$ad, $soyad, $ucret]);
    
    echo "<script>alert('Harika! Personel başarıyla eklendi.');</script>";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Takip Sistemi - VTYS Proje</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f7f6; padding: 30px; }
        .container { background: #ffffff; padding: 25px; border-radius: 10px; max-width: 700px; margin: auto; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h2 { color: #2c3e50; text-align: center; border-bottom: 2px solid #3498db; padding-bottom: 10px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #34495e; }
        input[type="text"], input[type="number"] { width: 95%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; }
        input[type="submit"] { background: #3498db; color: white; border: none; padding: 12px 20px; cursor: pointer; border-radius: 5px; width: 100%; font-size: 16px; font-weight: bold; transition: 0.3s; }
        input[type="submit"]:hover { background: #2980b9; }
        table { width: 100%; border-collapse: collapse; margin-top: 25px; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #2c3e50; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
    </style>
</head>
<body>

<div class="container">
    <h2>Yeni Personel Kayıt Ekranı</h2>
    
    <form method="POST" action="">
        <div class="form-group">
            <label>Personel Adı:</label>
            <input type="text" name="ad" required placeholder="Örn: Ahmet">
        </div>
        <div class="form-group">
            <label>Personel Soyadı:</label>
            <input type="text" name="soyad" required placeholder="Örn: Yılmaz">
        </div>
        <div class="form-group">
            <label>Saatlik Ücret (TL):</label>
            <input type="number" name="ucret" required placeholder="Örn: 250">
        </div>
        <input type="submit" name="kaydet" value="Sisteme Kaydet">
    </form>

    <h2>Sistemdeki Personeller</h2>
    
    <table>
        <tr>
            <th>ID</th>
            <th>Ad</th>
            <th>Soyad</th>
            <th>Saatlik Ücret</th>
        </tr>
        <?php
        // Veritabanındaki personelleri çek
        $personeller = $db->query("SELECT * FROM Personeller ORDER BY PersonelID DESC")->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($personeller as $personel) {
            echo "<tr>
                    <td>{$personel['PersonelID']}</td>
                    <td>{$personel['Ad']}</td>
                    <td>{$personel['Soyad']}</td>
                    <td>{$personel['SaatlikUcret']} TL</td>
                  </tr>";
        }
        ?>
    </table>
</div>

</body>
</html>