<?php
session_start();
if(isset($_POST['login'])){
    if($_POST['user'] == 'Anıl' && $_POST['pass'] == '1234'){
        $_SESSION['admin'] = true;
        header("Location: index.php");
    } else { $hata = "Hatalı kullanıcı adı veya şifre!"; }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sistem Girişi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #0f172a; display: flex; align-items: center; justify-content: center; height: 100vh; }
        .login-card { background: white; padding: 40px; border-radius: 20px; width: 400px; }
    </style>
</head>
<body>
    <div class="login-card shadow-lg text-center">
        <h3 class="mb-4 text-primary fw-bold">Sistem Girişi</h3>
        <?php if(isset($hata)) echo "<div class='alert alert-danger'>$hata</div>"; ?>
        <form method="POST">
            <input type="text" name="user" class="form-control mb-3" placeholder="Kullanıcı Adı" required>
            <input type="password" name="pass" class="form-control mb-3" placeholder="Şifre" required>
            <button type="submit" name="login" class="btn btn-primary w-100">Giriş Yap</button>
        </form>
    </div>
</body>
</html>